CREATE RULE dropdeclarationfile AS
    ON DELETE TO public.declaration_file DO  SELECT lo_unlink(old.file) AS lo_unlink;

