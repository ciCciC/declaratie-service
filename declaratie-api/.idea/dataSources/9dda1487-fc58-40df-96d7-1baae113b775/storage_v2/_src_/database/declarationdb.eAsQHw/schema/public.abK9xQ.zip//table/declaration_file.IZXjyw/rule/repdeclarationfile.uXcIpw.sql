CREATE RULE repdeclarationfile AS
    ON UPDATE TO public.declaration_file DO  SELECT lo_unlink(old.file) AS lo_unlink
  WHERE (old.file <> new.file);

